<?php 
	$upitSlika = "SELECT href FROM images";
 ?>